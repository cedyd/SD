This is a Windows build of Gpredict. Credit for the Windows build goes to:

V1.1: WBR, Valentin Yakovenkov
V1.2, 1.3: Alan Moffet, KE7IJZ

Gpredict is free, open source software licensed under the GNU GPL. You are
welcome to copy, modify and distribute it under the terms of this license.
The source code is avaialble from the website.

The executable gpredict.exe is in the bin directory. You need to execute it
from there. Of course, you can create a shortcut to gpredict.exe, just make
sure that it is "executed in" c:\gpredict\bin - or wherever gpredict is
installed.

Be sure to update your TLE files (see Edit->Update TLE) the first time you
run gpredict, otherwise the predictions will not be accuate.

For more info see http://gpredict.oz9aec.net/

73
Alex OZ9AEC
